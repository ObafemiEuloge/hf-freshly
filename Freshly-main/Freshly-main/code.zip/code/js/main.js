// Chargement du plugin sur le parent

$(function () {
    $(".slick").slick({
        slidesToShow: 1,
        dots: true,
        autoplay: true,
        autoplaySpeed: 1000,

    });
});