# Instruction

## Conteneur
Taille max du conteneur : 980px;

## Blocks
marge de 10px

## Couleurs
texte: #555;
fond de tous les blocks: rgba(0,0,0,0.1)
bordure de tous les blocks: rgba(0,0,0,0.2)