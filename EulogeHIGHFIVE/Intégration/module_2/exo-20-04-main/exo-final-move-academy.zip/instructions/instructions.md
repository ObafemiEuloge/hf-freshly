Exercice final Move Academy
===========================

L’ensemble du contenu fait 1200px de large et est centré sur la page du navigateur 
mais la couleur de fond du pied de page fait toute la largeur de la page du navigateur quelle que soit sa taille.

# COULEURS :
- textes : #363636
- violet foncé : #7e4a7c
- violet moyen : #b878b5
- violet fond clair (tableau et formulaire) : #ffeefe

# POLICES :
- par défaut : Open Sans (Google Font)
- Economica (Google Font) pour titres, nav, boutons

# TAILLE DES POLICES :
- par défaut : 16px
- titre : 50px
- titres rubriques : 40px
- titres sous-rubriques : 30px
- menu : 24px
- boutons "more" : 20px
- bouton validation formulaire : 25px
- copyright : 14px

# Les pictos de réseaux sociaux sont des Font Awesome