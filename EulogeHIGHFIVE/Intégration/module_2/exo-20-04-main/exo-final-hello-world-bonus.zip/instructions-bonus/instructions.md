# Exercice final: Hello World

Bonus

## Dans la page index.html
- Ajouter la pagination sous les deux voyages
- Modifier l'url du lien "En savoir plus" du voyage vers Vienne pour pointer vers la page "vienne.html"

## Ajouter la page vienne.html

### Menu
- Faire un lien de retour vers la page index.html

### Section Géographie
- Ajouter une carte de Vienne intéractive OpenStreetMap

### Section à Visiter
- Faire une galerie de lieux à visiter
